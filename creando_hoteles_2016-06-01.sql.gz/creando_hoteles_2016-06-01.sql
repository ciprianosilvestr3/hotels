# ************************************************************
# Sequel Pro SQL dump
# Versión 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Base de datos: creando_hoteles
# Tiempo de Generación: 2016-06-01 10:51:27 p.m. +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla categorias
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorias`;

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) DEFAULT NULL,
  `tipo_interes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_categorias_tipo_interes` (`tipo_interes`),
  CONSTRAINT `fk_categorias_tipo_interes` FOREIGN KEY (`tipo_interes`) REFERENCES `tipo_interes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla categorias_sitios_interes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorias_sitios_interes`;

CREATE TABLE `categorias_sitios_interes` (
  `categorias_id` int(11) NOT NULL,
  `sitios_interes_id` int(11) NOT NULL,
  KEY `fk_categorias_sitios_interes_categorias` (`categorias_id`),
  KEY `fk_categorias_sitios_interes_sitios` (`sitios_interes_id`),
  CONSTRAINT `fk_categorias_sitios_interes_categorias` FOREIGN KEY (`categorias_id`) REFERENCES `categorias` (`id`),
  CONSTRAINT `fk_categorias_sitios_interes_sitios` FOREIGN KEY (`sitios_interes_id`) REFERENCES `sitios_interes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla ciudades
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ciudades`;

CREATE TABLE `ciudades` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `estado_id` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estado_id` (`estado_id`) USING BTREE,
  CONSTRAINT `estado_id` FOREIGN KEY (`estado_id`) REFERENCES `estados` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla clientes_creando
# ------------------------------------------------------------

DROP TABLE IF EXISTS `clientes_creando`;

CREATE TABLE `clientes_creando` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `hotel` varchar(255) DEFAULT NULL,
  `base_datos` varchar(50) DEFAULT NULL,
  `estatus` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla estados
# ------------------------------------------------------------

DROP TABLE IF EXISTS `estados`;

CREATE TABLE `estados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pais_id` (`pais_id`) USING BTREE,
  CONSTRAINT `pais_id` FOREIGN KEY (`pais_id`) REFERENCES `paises` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla hoteles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `hoteles`;

CREATE TABLE `hoteles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `fecha_registro` datetime NOT NULL,
  `logo` longblob,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

LOCK TABLES `hoteles` WRITE;
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;

INSERT INTO `hoteles` (`id`, `nombre`, `fecha_nacimiento`, `email`, `telefono`, `fecha_registro`, `logo`, `estatus`)
VALUES
	(1,'Artisan','0000-00-00','artisan@hotmail.com','2299101125','0000-00-00 00:00:00',NULL,1);

/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla lenguajes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lenguajes`;

CREATE TABLE `lenguajes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla noticias
# ------------------------------------------------------------

DROP TABLE IF EXISTS `noticias`;

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `titulo` varchar(75) DEFAULT NULL,
  `descripción` mediumtext,
  `fecha_registro` datetime DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  `foto` longblob,
  PRIMARY KEY (`id`),
  KEY `fk_noticias_usuarios1_idx` (`usuario_id`) USING BTREE,
  CONSTRAINT `fk_noticias_usuarios1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla noticias_sucursales
# ------------------------------------------------------------

DROP TABLE IF EXISTS `noticias_sucursales`;

CREATE TABLE `noticias_sucursales` (
  `noticias_id` int(11) NOT NULL,
  `sucursales_id` int(11) NOT NULL,
  KEY `fk_noticias_sucursales` (`noticias_id`),
  KEY `fk_noticias_sucursales_1` (`sucursales_id`),
  CONSTRAINT `fk_noticias_sucursales` FOREIGN KEY (`noticias_id`) REFERENCES `noticias` (`id`),
  CONSTRAINT `fk_noticias_sucursales_1` FOREIGN KEY (`sucursales_id`) REFERENCES `sucursales` (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla paises
# ------------------------------------------------------------

DROP TABLE IF EXISTS `paises`;

CREATE TABLE `paises` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla perfiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `perfiles`;

CREATE TABLE `perfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla perfiles_recursos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `perfiles_recursos`;

CREATE TABLE `perfiles_recursos` (
  `consultar` tinyint(1) DEFAULT '0',
  `agregar` tinyint(1) DEFAULT '0',
  `editar` tinyint(1) DEFAULT '0',
  `eliminar` tinyint(1) DEFAULT '0',
  `recurso_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  KEY `fk_perfiles_recursos_recursos1_idx` (`recurso_id`) USING BTREE,
  KEY `fk_perfiles_recursos_perfiles1_idx` (`perfil_id`) USING BTREE,
  CONSTRAINT `fk_perfiles_recursos` FOREIGN KEY (`recurso_id`) REFERENCES `recursos` (`id`),
  CONSTRAINT `fk_perfiles_recursos_perfiles1` FOREIGN KEY (`perfil_id`) REFERENCES `perfiles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla productos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` mediumtext,
  `precio` double(8,0) DEFAULT NULL,
  `fecha_regitro` datetime DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `foto` longblob,
  PRIMARY KEY (`id`),
  KEY `fk_productos_usuarios` (`usuario_id`),
  CONSTRAINT `fk_productos_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;



# Volcado de tabla productos_sucursales
# ------------------------------------------------------------

DROP TABLE IF EXISTS `productos_sucursales`;

CREATE TABLE `productos_sucursales` (
  `productos_id` int(11) NOT NULL,
  `sucursales_id` int(11) NOT NULL,
  KEY `fk_productos_sucursales` (`productos_id`),
  KEY `fk_productos_sucursales_1` (`sucursales_id`),
  CONSTRAINT `fk_productos_sucursales` FOREIGN KEY (`productos_id`) REFERENCES `productos` (`id`),
  CONSTRAINT `fk_productos_sucursales_1` FOREIGN KEY (`sucursales_id`) REFERENCES `sucursales` (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla recursos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `recursos`;

CREATE TABLE `recursos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` int(11) DEFAULT NULL,
  `uuid` varchar(25) DEFAULT NULL,
  `lenguaje_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_settings_sucursales` (`sucursal_id`),
  KEY `fk_settings_lenguales` (`lenguaje_id`),
  CONSTRAINT `fk_settings_lenguales` FOREIGN KEY (`lenguaje_id`) REFERENCES `lenguajes` (`id`),
  CONSTRAINT `fk_settings_sucursales` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla sitios_interes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sitios_interes`;

CREATE TABLE `sitios_interes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(300) DEFAULT NULL,
  `latitud` varchar(50) DEFAULT NULL,
  `longitud` varchar(50) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `ciudad_id` int(6) DEFAULT NULL,
  `foto` longblob,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ciudad_id` (`ciudad_id`) USING BTREE,
  CONSTRAINT `fk_sitios_interes_ciudades` FOREIGN KEY (`ciudad_id`) REFERENCES `ciudades` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla sucursales
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sucursales`;

CREATE TABLE `sucursales` (
  `id_sucursal` int(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `latitud` varchar(50) DEFAULT '',
  `longitud` varchar(50) DEFAULT '',
  `direccion` varchar(50) DEFAULT '',
  `telefono` varchar(15) DEFAULT NULL,
  `hoteles_id` int(11) DEFAULT NULL,
  `fecha_registro` datetime NOT NULL,
  `estatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`),
  KEY `cliente_id` (`hoteles_id`) USING BTREE,
  KEY `cliente_id_2` (`hoteles_id`) USING BTREE,
  KEY `cliente_id_3` (`hoteles_id`) USING BTREE,
  KEY `cliente_id_4` (`hoteles_id`) USING BTREE,
  KEY `cliente_id_5` (`hoteles_id`) USING BTREE,
  CONSTRAINT `fk_sucursales_hoteles` FOREIGN KEY (`hoteles_id`) REFERENCES `hoteles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;

INSERT INTO `sucursales` (`id_sucursal`, `nombre`, `latitud`, `longitud`, `direccion`, `telefono`, `hoteles_id`, `fecha_registro`, `estatus`)
VALUES
	(1,'Chachalacas','','','',NULL,1,'0000-00-00 00:00:00',1);

/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla sucursales_ciudades
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sucursales_ciudades`;

CREATE TABLE `sucursales_ciudades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursales_id` int(11) DEFAULT NULL,
  `ciudades_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sucursales_ciudades_sucursales` (`sucursales_id`),
  KEY `fk_sucursales_ciudades_ciudades` (`ciudades_id`),
  CONSTRAINT `fk_sucursales_ciudades_ciudades` FOREIGN KEY (`ciudades_id`) REFERENCES `ciudades` (`id`),
  CONSTRAINT `fk_sucursales_ciudades_sucursales` FOREIGN KEY (`sucursales_id`) REFERENCES `sucursales` (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla tipo_interes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tipo_interes`;

CREATE TABLE `tipo_interes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;



# Volcado de tabla tipos_de_interes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tipos_de_interes`;

CREATE TABLE `tipos_de_interes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla usuarios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(45) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `estatus` tinyint(1) NOT NULL,
  `foto` longblob,
  `sucursales_id` int(11) DEFAULT NULL,
  `usuario` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `fk_usuarios_sucursales` (`sucursales_id`),
  CONSTRAINT `fk_usuarios_sucursales` FOREIGN KEY (`sucursales_id`) REFERENCES `sucursales` (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `fecha_registro`, `estatus`, `foto`, `sucursales_id`, `usuario`)
VALUES
	(1,'alejandro','alex_silver_andrade@hotmail.com','alejandro','0000-00-00 00:00:00',1,NULL,1,'alejandro');

/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla usuarios_perfiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usuarios_perfiles`;

CREATE TABLE `usuarios_perfiles` (
  `usuario_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  KEY `fk_usuarios_perfiles_usuarios_idx` (`usuario_id`) USING BTREE,
  KEY `fk_usuarios_perfiles_perfiles1_idx` (`perfil_id`) USING BTREE,
  CONSTRAINT `fk_usuarios_perfiles` FOREIGN KEY (`perfil_id`) REFERENCES `perfiles` (`id`),
  CONSTRAINT `fk_usuarios_perfiles_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
